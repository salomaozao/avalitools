br2_format <- scales::number_format(accuracy = 0.01,
                                    big.mark = ".",
                                    decimal.mark = ",")