br3_format <- scales::number_format(accuracy = 10^-3,
                                    big.mark = ".",
                                    decimal.mark = ",")